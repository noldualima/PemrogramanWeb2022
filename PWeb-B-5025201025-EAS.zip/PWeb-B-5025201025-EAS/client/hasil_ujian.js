$(document).ready(function() {
    $("#isi-data-pendaftaran").click(function() {
        window.location.href = "./isi_data_pendaftaran.php"
    });

    $("#upload-berkas").click(function() {
        window.location.href = "./upload-berkas.php";
    });
});