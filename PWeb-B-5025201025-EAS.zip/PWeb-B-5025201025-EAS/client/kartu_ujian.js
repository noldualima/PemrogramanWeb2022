$(document).ready(function() {
    $("#button-unduh").click(function() {
        window.location.href = "../server/kartu_ujian.php";
    });
});